# Contributors

Name | GitHub user | Role
--- | --- | ---
Johann-Mattis List | @LinguList | maintainer
